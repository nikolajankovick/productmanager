package rs.ac.singidunum.www;

public class Colors {
	private int id;
	private String  colorname;
	
	public Colors(int id, String colorname) {
		super();
		this.id=id;
		this.colorname=colorname;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getColorname() {
		return colorname;
	}

	public void setColorname(String colorname) {
		this.colorname = colorname;
	}
}
