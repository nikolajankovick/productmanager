package rs.ac.singidunum.www;

import java.util.ArrayList;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RestAppController {
	
	@GetMapping("/redcolor/")
	public Colors getRedColor() {
		return new Colors(1, "Red");
	}
	@GetMapping("/allcolors/")
	public List<Colors> getColors() {
		List<Colors> colors = new ArrayList<Colors>();
		
		colors.add(new Colors(1, "Red"));
		colors.add(new Colors(2, "Black"));
		colors.add(new Colors(3, "Green"));
		colors.add(new Colors(4, "Blue"));
		
		return colors;
	}
	@GetMapping("/colors/{id}")
	public ResponseEntity<Colors> getColor(@PathVariable int id) {
		if (id==1) {
			Colors colors = new Colors(1, "Red");
			return new ResponseEntity<Colors>(colors,HttpStatus.OK);	
		}
		if (id==2) {
			Colors colors = new Colors(2, "Black");
			return new ResponseEntity<Colors>(colors,HttpStatus.OK);
		}
		if (id==3) {
			Colors colors = new Colors(3, "Green");
			return new ResponseEntity<Colors>(colors,HttpStatus.OK);
		}
		if (id==4) {
			Colors colors = new Colors(4, "Blue");
			return new ResponseEntity<Colors>(colors,HttpStatus.OK);
		}
		else {
				return new ResponseEntity<Colors>(HttpStatus.NOT_FOUND);
			}
		}
	}

	
	

