package rs.ac.singidunum.www;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class UserService {
	
	@Autowired
	private UserRepository repo;
		
	public List<user> listAll() {
		return repo.findAll();
	}
	
	public user get(Long id_name) {
		return repo.findById(id_name).get();
	}
	public void save(user user) {
		repo.save(user);
	}
	
	public void delete(Long id_name) {
		repo.deleteById(id_name);
	}
}
